<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ page import="web.miniProject.dto.MemberDTO" %>

<% 
	MemberDTO sdtoMain = (MemberDTO) session.getAttribute("loginUser"); 

	// 세션 없음
	if(sdtoMain == null){	// 비로그인 상태
		
		// 자동 로그인 쿠키 값을 저장할 변수 선언
		String cid = null, cpw = null, cauto = null;
	
		// 브라우저에서 넘어온 쿠키 꺼냄
		Cookie[] cookies = request.getCookies();
		
		// 쿠키 존재
		if(cookies != null){
			// 쿠키 하나씩 꺼내서 확인
			for(Cookie c : cookies){
				if(c.getName().equals("cid")){ cid = c.getValue(); }
				if(c.getName().equals("cpw")){ cpw = c.getValue(); }
				if(c.getName().equals("cauto")){ cauto = c.getValue(); }
			}
		}
		// 쿠키가 하나라도 있으면	→ 자동로그인 시도
		if(cid != null || cpw != null || cauto != null){
			response.sendRedirect("loginPro.jsp");
		}
	}
%>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>맛침반</title>

<link rel="stylesheet" href="<%=request.getContextPath()%>/css/main.css">

</head>
<body>

<!-- ================= HEADER ================= -->
<%@ include file="header.jsp" %>

<!-- ================= HERO ================= -->

<section class="hero">

    <div class="overlay">

        <div class="heroText">
            <h1>
                오늘 뭐 먹지?<br>
                맛있는 선택, <span>맛침반</span>
            </h1>

            <p>
                다양한 맛집 정보와 평가로<br>
                당신의 미식 여정을 함께합니다.
            </p>

        </div>

        <div class="searchBox">

            <form action="search.jsp">

                <input type="text"
                    name="keyword"
                    placeholder="검색어를 입력해 주세요 (예: 파스타, 홍대, 스시...)">

                <button>🔍</button>

            </form>

        </div>

    </div>

</section>

<!-- ================= 맛집공유 인기글 ================= -->

<div class="content">
	<div class="sectionHeader">
	    <div class="sectionTitle">
	        맛집공유 인기글 🔥
	    </div>
	    <a href="" class="morebtn">더보기 ></a>
	</div>
    <div class="cardContainer">

        <!-- 카드 1 -->

        <div class="card">
        	<div class="imgBox">
        		<img src="../images/pasta.jpg">
				<span class="location">홍대</span>
        	</div>
            <div class="cardBody">   
                <h3>분위기 좋은 홍대 파스타 맛집</h3>
				<div class="cardFooter">
	                <div class="writer"> 맛집러버 </div>
	                <div class="info">
	                    ♡ 152 &nbsp;&nbsp; ★ 42 &nbsp;&nbsp; 💬 24
	                </div>
                </div>
            </div>
        </div> 

        <!-- 카드 2 -->

        <div class="card">
        	<div class="imgBox">
        		<img src="../images/pasta.jpg">
				<span class="location">홍대</span>
        	</div>
            <div class="cardBody">   
                <h3>분위기 좋은 홍대 파스타 맛집</h3>
				<div class="cardFooter">
	                <div class="writer"> 맛집러버 </div>
	                <div class="info">
	                    ♡ 152 &nbsp;&nbsp; ★ 42 &nbsp;&nbsp; 💬 24
	                </div>
                </div>
            </div>
        </div> 

        <!-- 카드 3 -->

        <div class="card">
        	<div class="imgBox">
        		<img src="../images/pasta.jpg">
				<span class="location">홍대</span>
        	</div>
            <div class="cardBody">   
                <h3>분위기 좋은 홍대 파스타 맛집</h3>
				<div class="cardFooter">
	                <div class="writer"> 맛집러버 </div>
	                <div class="info">
	                    ♡ 152 &nbsp;&nbsp; ★ 42 &nbsp;&nbsp; 💬 24
	                </div>
                </div>
            </div>
        </div>    
            
    </div>
</div>

<!-- ================= 맛집평가단 인기글 ================= -->

<div class="content">
	<div class="sectionHeader">
	    <div class="sectionTitle">
	        맛집평가단 인기글 🔥
	    </div>
	    <a href="" class="morebtn">더보기 ></a>
	</div>
    <div class="cardContainer">

        <!-- 카드 1 -->

        <div class="card">
        	<div class="imgBox">
        		<img src="../images/pasta.jpg">
				<span class="pickBadge">평가단 PICK</span>
        	</div>
            <div class="cardBody">   
                <h3>분위기 좋은 홍대 파스타 맛집</h3>
				<div class="cardFooter">
	                <div class="writer"> 맛집러버 </div>
	                <div class="info">
	                    ♡ 152 &nbsp;&nbsp; ★ 42
	                </div>
                </div>
            </div>
        </div> 

        <!-- 카드 2 -->

        <div class="card">
        	<div class="imgBox">
        		<img src="../images/pasta.jpg">
				<span class="pickBadge">평가단 PICK</span>
        	</div>
            <div class="cardBody">   
                <h3>분위기 좋은 홍대 파스타 맛집</h3>
				<div class="cardFooter">
	                <div class="writer"> 맛집러버 </div>
	                <div class="info">
	                    ♡ 152 &nbsp;&nbsp; ★ 42
	                </div>
                </div>
            </div>
        </div> 

        <!-- 카드 3 -->

        <div class="card">
        	<div class="imgBox">
        		<img src="../images/pasta.jpg">
				<span class="pickBadge">평가단 PICK</span>
        	</div>
            <div class="cardBody">   
                <h3>분위기 좋은 홍대 파스타 맛집</h3>
				<div class="cardFooter">
	                <div class="writer"> 맛집러버 </div>
	                <div class="info">
	                    ♡ 152 &nbsp;&nbsp; ★ 42
	                </div>
                </div>
            </div>
        </div>    
            
    </div>
</div>




</body>
</html>