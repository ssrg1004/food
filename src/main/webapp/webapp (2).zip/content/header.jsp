<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ page import="web.miniProject.dto.MemberDTO" %>

<% 
	MemberDTO sdtoHeader = (MemberDTO) session.getAttribute("loginUser"); 
%>
<header>
    <div class="logo">
        <a href="<%=request.getContextPath()%>/content/main.jsp">🍽️ 맛침반</a>
    </div>
    <nav>
        <a href="<%=request.getContextPath()%>/content/restaurant/restaurantList.jsp">맛집공유</a>
        <a href="#">맛집평가단</a>
        <a href="#">맛집지도</a>
        <a href="#">공지사항</a>
    </nav>

    <div class="userBlock">
    <!-- 로그인 X -->
    <% if(sdtoHeader == null) { %>
       	<button class="loginBtn" onclick="window.location='<%=request.getContextPath()%>/content/member/loginForm.jsp'">로그인</button>
    <!-- 로그인 했을 시 -->
   	<%}else { %>
   		<a href="<%=request.getContextPath()%>/content/myPage.jsp">
       		<img class="personImg" src="<%=request.getContextPath()%>/images/person.png">
       	</a>
   		<div>
   			<a class="headNickname" href="<%=request.getContextPath()%>/content/myPage.jsp"><%=sdtoHeader.getNickname() %></a>
   			 님 환영합니다.
   		</div>
		<button class="logoutBtn" onclick="window.location='<%=request.getContextPath()%>/content/member/logoutForm.jsp'">로그아웃</button>
   	<%} %>

    </div>
</header>
