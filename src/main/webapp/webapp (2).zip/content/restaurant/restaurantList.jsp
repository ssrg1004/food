<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!--============ session 값 받아오기 위한 공통코드 ============-->
<%@ page import="web.miniProject.dto.MemberDTO" %>   
<!-- 변수 이름은 페이지마다 변경해야함. 
	sdtoRest , sdtoMain, sdtoHeader 등등 ...-->
<% MemberDTO sdtoRest = (MemberDTO) session.getAttribute("loginUser"); %>

<%
/*********** url 정보 저장, 데이터 불러오기용 변수 작업 ***********/

	// 필터링용 값 받아오기 
	
	String category = request.getParameter("category");
	String sort = request.getParameter("sort");
	
	// 화면 첫 진입 시 "전체"버튼으로 초기화
	if(category == null)
	    category = "all";
	// 화면 첫 진입 시 "최신순"으로 초기화
	if(sort == null)
	    sort = "latest";
	
	// 한 페이지에 보여줄 줄 수
	int pageLineSize = 5;
	
	// URL 에서 현재 페이지번호 꺼내기		-> ?pageNum=2
	String pageNum = request.getParameter("pageNum");
	
	// 처음 접속 시 pageNum 없으면 기본값 1
	if( pageNum == null || pageNum.equals("null")){
		pageNum = "1";
	}
	// 한 페이지에 보여줄 줄의 수 url에서 가져오기
	String pageLineSizeParam = request.getParameter("pageLineSize");
	if(pageLineSizeParam != null){
		pageLineSize = Integer.parseInt(pageLineSizeParam);
	}

	// 현재 페이지 번호 -> 계산에 사용
	int currentPage = Integer.parseInt(pageNum);
	
	// 현재 페이지의 시작/끝 행 번호 계산
	int startRow = (currentPage-1) * (pageLineSize*4) + 1;
	int endRow = currentPage * (pageLineSize*4) ;
	
	// 실제 글 데이터 가져오는 코드 작성칸 
	/**********************************************************************/
	/* 
	// DAO 에서 start ~ end 범위의 게시글 가져오기
	ArrayList<Board1DTO> list2 = dao.list2(startRow, endRow);
	
	// 날짜 시간 출력포맷 설정
	SimpleDateFormat adf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	
	// DAO 에서 글 개수 가져오기
	int count = dao.listCount();
	*/
	/**********************************************************************/

	int count = 25; // 테스트용 : 총 글 수 (위에 데이터 가져오는 코드 작성되면 삭제하기)
%>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>맛침반</title>

<link rel="stylesheet" href="<%=request.getContextPath()%>/css/main.css">

<link rel="stylesheet"
	href="<%=request.getContextPath()%>/css/restaurantList.css">

</head>

<body>
<!-- ================= HEADER ================= -->
<jsp:include page="../header.jsp"/>

<div class="restaurantContainer">

	<!-- 검색 -->
	<div class="searchArea">
		
		<!-- 필터버튼(구현하지않기. 주석처리함) -->
		<!--
		<button class="filterBtn" onclick="openFilter()">

			<img
			src="<%=request.getContextPath()%>/images/filter.png"
			alt="필터">

		</button>
 		-->
	
		<input
			type="text"
			placeholder="지역, 상호명, 음식종류 검색">
		<button>🔍</button>
	</div>

	<!-- ================== 태그 ================== -->

	<div class="tagArea">
		<!-- tag 테이블에서 값 순서대로 가져와야함(맨 처음의 '전체'버튼 제외) -->
		<a href="#" class="tagBtn active">전체</a>
		<a href="#" class="tagBtn">한식</a>
		<a href="#" class="tagBtn">중식</a>
		<a href="#" class="tagBtn">일식</a>
		<a href="#" class="tagBtn">양식</a>
		<a href="#" class="tagBtn">카페</a>
		<a href="#" class="tagBtn">디저트</a>
		<a href="#" class="tagBtn">술집</a>

	</div>
	
	<!-- ================== (관리자용) 맛집추가 ================== -->
	<!-- 세션값으로 관리자확인 후 버튼 보이도록 if문 처리하기 -->
	<% if(sdtoRest != null && sdtoRest.getRole().equals("admin")) { %>
	<div class="addRestaurantBtn">
		<a href="#">맛집 등록</a>
	</div>
	<script>console.log("equals admin:<%=sdtoRest.getRole().equals("admin")%>");</script>
	<% } %>
	
	
	<!-- ================== 맛집리스트 필터링 ================== -->
	<div class="sortArea">
	 	<button class="sortBtn active" data-sort="latest">최신순</button>
		<button class="sortBtn"data-sort="like">좋아요순</button>
		<button class="sortBtn" data-sort="comment">댓글순</button>
		<button class="sortBtn" data-sort="view">조회순</button>
	</div>
	
	
	<!-- ================== 맛집 카드 ================== -->
	<div class="restaurantArea">

		<% for(int i=1; i<=25; i++){ %>

		<a href="restaurantDetail.jsp?id=<%=i%>"
			class="restaurantCard">

			<div class="cardImage">
				<img
				src="<%=request.getContextPath()%>/images/pasta.jpg">
			</div>

			<div class="cardContent">
				<div class="titleRow">
					<div class="storeName">
						성수국밥
					</div>
					<div class="iconArea">
						<button type="button" class="likeBtn"
							onclick="event.preventDefault(); 
									event.stopPropagation()">
							<!--		likeToggle()">-->
							<%-- <%if(dto.isLiked())%> --%>
								<img src="<%=request.getContextPath()%>/images/heart-fill.png">
							<%-- <%}else {%> --%>
								<!-- <img src="../images/heart-empty.png"> -->
							<%-- <%}%> --%>
						</button>
						<button type="button" class="bookmarkBtn"
							onclick="event.preventDefault(); 
									event.stopPropagation()"> 
							<!-- 		bookmarkToggle()"> -->
							<%-- <%if (dto.isBookmarked())%> --%>
								<img src="<%=request.getContextPath()%>/images/bookmark-fill.png">
							<%-- <%}else {%> --%>
								<!-- <img src="../images/heart-empty.png"> -->
							<%-- <%}%> --%>
						</button>
					</div>
				</div>

				<div class="commentRow">
					<img src="<%=request.getContextPath()%>/images/commentImg.png" class="commentIcon">
					<span class="commentCount">25</span>
				</div>
				<div class="addressRow">
					📍 서울 성동구 성수동
				</div>

			</div>

		</a>

		<% } %>

	</div>


	<!-- ================== 페이징 ================== -->
 	<div class="paging" style="text-align:center">
	<%
		// 게시글이 있을 때만 페이징 링크 생성
		if( count > 0 ){
			// 전체 페이지 수 계산
			int pageCount = count/(pageLineSize*4) + (count % (pageLineSize*4) == 0 ? 0 : 1);

			// 한번에 보여줄 페이지 수 [1] [2] [3] ... [10] 10개 보여줌
			int pageBlock = 10;
			
			// 현재 블록의 시작페이지 번호
			int startPage = (int)( (currentPage-1)/pageBlock ) * pageBlock + 1;
			
			// 현재 블록의 끝 페이지 번호
			int endPage = startPage + pageBlock - 1;

			// 끝 페이지가 전체 페이지 수보다 큰 경우 -> 전체 페이지 수로 조정 
			if( endPage > pageCount ){
				endPage = pageCount;	// 남아있는 페이지만 표시
			}
			
			// [이전] / [페이지번호] / [다음]
			
			// [이전] 버튼		: 현재 페이지 블록이 두 번째 이상일 때만 표시
			if( startPage > pageBlock ){
	%>			<a href="restaurantList.jsp?page=like&pageNo=<%=startPage-pageBlock%>&pageLineSize=<%=pageLineSize%>">이전</a>
	<%		}
			
			// 현재 페이지 번호 버튼 [1][2][3] ... [10]
			for(int i = startPage; i <= endPage; i++){
				
	%>			<a href="restaurantList.jsp?page=like&pageNo=<%=i%>&pageLineSize=<%=pageLineSize%>"><%=i %></a>
				
	<%		}
			
			// [다음] 버튼		: 다음 블록이 있을때만 표시
			if( endPage < pageCount ){
	%>			<a href="restaurantList.jsp?page=like&pageNo=<%= startPage + pageBlock %>&pageLineSize=<%=pageLineSize%>">다음</a>
	<%		}
		}
	
	%>	
	</div>
</div>

<script>

// 태그 복수선택 처리
const tagBtns = document.querySelectorAll(".tagBtn");

tagBtns.forEach(btn => {
	btn.addEventListener("click",
			
	function(e){
		e.preventDefault();
		const tagName = this.textContent.trim();

		if(tagName === "전체"){
			tagBtns.forEach(b => b.classList.remove("active"));
			this.classList.add("active");
			return;
		}

		const allBtn = document.querySelector(".tagBtn");
		allBtn.classList.remove("active");
		
		this.classList.toggle("active");
	});
});

// 좋아요/북마크/댓글/조회수 순 처리
const sortBtns = document.querySelectorAll(".sortBtn");

sortBtns.forEach(btn => {
    btn.addEventListener("click", function(){
        sortBtns.forEach(b => b.classList.remove("active"));
        this.classList.add("active");
    });

});

// 좋아요버튼 누를 시 처리
// (북마크버튼도 처리할 코드 비슷하게 작성하기)
function likeToggle(restaurantId){

    $.ajax({
        url : "likeToggle.jsp",
        type : "post",
        data : {
            restaurantId : restaurantId
        },
        success : function(result){
            // 하트 변경
        }
    });

}


</script>


</body>
</html>