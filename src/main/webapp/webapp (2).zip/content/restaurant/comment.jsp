<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!--------------------------------------------------------->
<!--------------------- 맛집 댓글 구현부분 --------------------->
<!--------------------------------------------------------->
<%@ page import="web.miniProject.dto.MemberDTO" %>
<%@ page import="java.util.List" %>
<%@ page import="java.util.ArrayList" %>
<%@ page import="web.miniProject.dto.CommentDTO" %>

<% 	MemberDTO sdtoComment = (MemberDTO) session.getAttribute("loginUser");  %>

<jsp:useBean class="web.miniProject.dao.CommentDAO" id="dao"/>

<%
	// 한 페이지에 보여줄 댓글 수
	int commentPageSize = 10;

	//URL 에서 현재 페이지번호 꺼내기		-> ?pageNum=2
	String pageNum = request.getParameter("pageNum");
	
	// 처음 접속 시 pageNum 없으면 기본값 1
	if( pageNum == null || pageNum.equals("null")){
		pageNum = "1";
	}
	// 한 페이지에 보여줄 줄의 수 url에서 가져오기
	String commentPageSizeParam = request.getParameter("commentPageSize");
	if(commentPageSizeParam != null){
		commentPageSize = Integer.parseInt(commentPageSizeParam);
	}
	// 현재 페이지 번호 -> 계산에 사용
	int currentPage = Integer.parseInt(pageNum);
	
	// 현재 페이지의 시작/끝 행 번호 계산
	int startRow = (currentPage-1) * commentPageSize + 1;
	int endRow = currentPage * commentPageSize ;
	
	System.out.println("startRow : "+startRow);
	System.out.println("endRow : "+endRow);
	
	/* 실제 댓글 데이터 가져오기 */
	List<CommentDTO> list = new ArrayList<CommentDTO>();
	int post_id = 1;		// ---------------------------** 맛집 post_id 받아오기
	
	int count = dao.comment_count(post_id);
	System.out.println("count : "+count);
	list = dao.getCommentList(post_id, startRow, endRow);
/*	CommentDTO dto1 = (CommentDTO) list.get(1);
	CommentDTO dto2 = (CommentDTO) list.get(2);
	System.out.println("content1 :"+dto1.getContent());
	System.out.println("content2 :"+dto2.getContent());*/

%>
    
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>맛침반</title>

<link rel="stylesheet" href="<%=request.getContextPath()%>/css/comment.css">

</head>
<body>

<div class="commentSection">

    <h3>댓글 <%=count %>개</h3>

    <!-- 댓글 목록 -->
    <div class="commentList">
	
	<!-- 댓글 목록(댓글 없을 시) -->
	<%if(count == 0){ %>
		<div class="commentItem">
			<div class="commentHeader">
				<div class="commentInfo"></div>
			</div>
			<div class="commentContent_none">
                작성된 댓글이 없습니다.
            </div>
		</div>
		
	<!-- 댓글 목록(댓글 하나라도 있을 시) -->
	<%}else {%>
		<!-- 반복으로 댓글 꺼내기 -->
		<% 	for(int i = 0; i < list.size(); i++){ 
				CommentDTO dto = (CommentDTO) list.get(i);
		%>
        <!-- 부모 댓글 -->
        <div class="commentItem">
            <div class="commentHeader">
            	<div class="commentInfo">
                	<span class="nickname"><%=dto.getNickname() %></span>
                	<!-- 댓글 별 별점표시 -->
		            <span class="rating">
					<% 	// 별 표시
						for(int j = 0; j < dto.getStar_score(); j++){ %>
							<img class="starImg" src="<%=request.getContextPath()%>/images/star.png">
					<%	}
						// 빈 별 표시
						//for(int i=dto.getStarScore(); i<5; i++){
						%><!-- ☆ --><%
						//}
						%>
					</span>      
                </div>
                <span class="commentDate"><%=dto.getReg_date() %></span>
 
                <!-- 본인 댓글 -->
                <span class="commentBtn">
                    <!-- 타인 글일 때 - 답글버튼 / 신고버튼 -->
                    <%if(sdtoComment.getMember_id() != dto.getMember_id()){ %>
                 	   <button onclick="toggleReplyForm(<%=dto.getComment_id() %>)">답글</button>
	                    <button>신고</button>
                    <%}else { %>
	                    <!-- 본인 글일 때 신고버튼은 X, 수정/삭제버튼 보임 -->
	                    <button>수정</button>
	                    <button>삭제</button>
                    <%} %>
                </span>

                <!-- 타인 댓글 -->
                <!-- <button>신고</button> -->
            </div>
            

            <div class="commentContent">
                <%=dto.getContent() %>
            </div>
		    <div id="replyForm<%=dto.getComment_id() %>" class="replyForm" style="display:none;">
			    <textarea placeholder="댓글을 입력해주세요."></textarea>	
			    <button>답글작성</button>
			</div>

        </div>
		
		<%	} %>
	
	
        <!-- 부모 댓글 -->
        <div class="commentItem">
            <div class="commentHeader">
            	<div class="commentInfo">
                	<span class="nickname">맛집헌터</span>
                	<!-- 댓글 별 별점표시 -->
		            <span class="rating">★★★★★
						<%
						// 별 표시
						//for(int i=0; i<dto.getStarScore(); i++){
						%><!-- ★ --><%
						//}
						// 빈 별 표시
						//for(int i=dto.getStarScore(); i<5; i++){
						%><!-- ☆ --><%
						//}
						%>
					</span>      
                </div>
                <span class="commentDate">2026-06-15 13:00</span>
 
                <!-- 본인 댓글 -->
                <span class="commentBtn">
                	<button onclick="toggleReplyForm(1)">답글</button>
                	<!-- <button onclick="toggleReplyForm(${dto.commentId})"> -->
                    
                    <!-- 타인 글일 때 신고버튼 보임 -->
                    <button>신고</button>
                    <!-- 본인 글일 때 신고버튼은 X, 수정/삭제버튼 보임 -->
                    <button>수정</button>
                    <button>삭제</button>
                </span>

                <!-- 타인 댓글 -->
                <!-- <button>신고</button> -->
            </div>
            

            <div class="commentContent">
                진짜 맛있네요.
            </div>
		    <div id="replyForm1" class="replyForm" style="display:none;">
			    <!-- <div id="replyForm${dto.commentId}" class="replyForm" style="display:none;"> -->
			    <textarea placeholder="댓글을 입력해주세요."></textarea>	
			    <button>답글작성</button>
			</div>

        </div>


        <!-- 대댓글 -->
        <div class="replyItem">

            <div class="commentHeader">
                <span class="replyMark">└</span>
                <span class="nickname">먹보대장</span>
                <span class="commentDate">2026-06-15 13:10</span>
                <button>신고</button>
            </div>

            <div class="commentContent">
                저도 인정합니다.
            </div>
        </div>
    </div>
	<%} %>


    <!-- 댓글 작성 -->
    <div class="commentWrite">

        <span class="myNickname">
            홍길동
        </span>
      
		<!-- 별점 -->
		  <div class="ratingArea">
		
		      <label>
		          <input type="radio" name="rating" value="5">
		          ★★★★★
		      </label>
		
		      <label>
		          <input type="radio" name="rating" value="4">
		          ★★★★☆
		      </label>
		
		      <label>
		          <input type="radio" name="rating" value="3">
		          ★★★☆☆
		      </label>
		
		      <label>
		          <input type="radio" name="rating" value="2">
		          ★★☆☆☆
		      </label>
		
		      <label>
		          <input type="radio" name="rating" value="1">
		          ★☆☆☆☆
		      </label>
		</div>
    	<div class="writeArea">
	        <textarea placeholder="댓글을 입력해주세요."></textarea>
	        <button class="writeBtn">작성</button>
        </div>

    </div>

</div>

<!-- 페이징 -->
<div class="paging" style="text-align:center">
<%
	// 댓글이 있을 때만 페이징 링크 생성
	if( count > 0 ){
		// 전체 페이지 수 계산
		int pageCount = count/commentPageSize + (count % commentPageSize == 0 ? 0 : 1);
		
		// 한번에 보여줄 페이지 수 [1] [2] [3] ... [10] 10개 보여줌
		int pageBlock = 10;
		
		// 현재 블록의 시작페이지 번호
		int startPage = (int)( (currentPage-1)/pageBlock ) * pageBlock + 1;
		
		// 현재 블록의 끝 페이지 번호
		int endPage = startPage + pageBlock - 1;
		
		// 끝 페이지가 전체 페이지 수보다 큰 경우 -> 전체 페이지 수로 조정 
		if( endPage > pageCount ){
			endPage = pageCount;	// 남아있는 페이지만 표시
		}
		
		// [이전] / [페이지번호] / [다음]
		
		// [이전] 버튼		: 현재 페이지 블록이 두 번째 이상일 때만 표시
		if( startPage > pageBlock ){
%>			<a href="comment.jsp?page=like&pageNo=<%=startPage-pageBlock%>&commentPageSize=<%=commentPageSize%>">이전</a>
<%		}
		
		// 현재 페이지 번호 버튼 [1][2][3] ... [10]
		for(int i = startPage; i <= endPage; i++){
%>			<a href="comment.jsp?page=like&pageNo=<%=i%>&commentPageSize=<%=commentPageSize%>"><%=i %></a>
<%		}
		
		// [다음] 버튼		: 다음 블록이 있을때만 표시
		if( endPage < pageCount ){
%>			<a href="comment.jsp?page=like&pageNo=<%= startPage + pageBlock %>&commentPageSize=<%=commentPageSize%>">다음</a>
<%		}
	}
%>	
</div>

</body>

<script>
function toggleReplyForm(comment_id){

    let replyForm = document.getElementById("replyForm" + comment_id);

    if(replyForm.style.display == "none"){
        replyForm.style.display = "flex";
    }else{
        replyForm.style.display = "none";
    }
}
</script>

</html>