<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ page import="web.miniProject.dto.MemberDTO" %>
<%@ page import="web.miniProject.dto.ReviewerPostDTO" %>
<%@ page import="web.miniProject.dao.ReviewerPostDAO" %>

<%
request.setCharacterEncoding("UTF-8");

MemberDTO loginUser = (MemberDTO) session.getAttribute("loginUser");

/* 권한 체크 */
if (loginUser == null || !"Y".equals(loginUser.getReviewer_yn())) {
%>
<script>
    alert("권한이 없습니다.");
    location.href = "reviewerPostList.jsp";
</script>
<%
    return;
}

/* 파라미터 수신 (이전 폼의 name="post_id"와 일치하도록 수정 완료) */
int post_id = Integer.parseInt(request.getParameter("post_id"));
String title = request.getParameter("title");
String region = request.getParameter("region");
String content = request.getParameter("content");

/* DTO */
ReviewerPostDTO dto = new ReviewerPostDTO();
dto.setPost_id(post_id);
dto.setMember_id(loginUser.getMember_id());
dto.setTitle(title);
dto.setRegion(region);
dto.setContent(content);

/* DAO */
ReviewerPostDAO dao = ReviewerPostDAO.getInstance();
dao.updateDraft(dto);
%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<link rel="stylesheet" href="<%=request.getContextPath()%>/css/reviewer.css">
</head>
<body>

<script>
alert("수정 요청 완료 (관리자 승인 대기)");
location.href = "reviewerPostList.jsp";
</script>

</body>
</html>