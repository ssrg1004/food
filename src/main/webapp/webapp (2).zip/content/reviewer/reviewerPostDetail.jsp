<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>

<%@ page import="java.util.*" %>
<%@ page import="web.miniProject.dto.*" %>
<%@ page import="web.miniProject.dao.*" %>

<%
MemberDTO loginUser = (MemberDTO)session.getAttribute("loginUser");

String post_idStr = request.getParameter("post_id");

/* =========================
   잘못된 접근 차단
========================= */
if(post_idStr == null){
    response.sendRedirect("reviewerPostList.jsp");
    return;
}

int post_id = Integer.parseInt(post_idStr);

ReviewerPostDAO dao = ReviewerPostDAO.getInstance();


/* =========================
   게시글 상세
========================= */
ReviewerPostDTO dto = dao.getPost(post_id);

/* =========================
   게시글 없음 처리
========================= */
if(dto == null){
    response.sendRedirect("reviewerPostList.jsp");
    return;
}

/* =========================
   이미지 리스트
========================= */
ArrayList<ReviewerImageDTO> imgList =
    dao.getImages(post_id);

if(imgList == null){
    imgList = new ArrayList<>();
}
%>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">

<title><%=dto.getTitle()%></title>

<link rel="stylesheet"
href="<%=request.getContextPath()%>/css/main.css">

<link rel="stylesheet"
href="<%=request.getContextPath()%>/css/reviewer.css">

</head>

<body>

<jsp:include page="../header.jsp"/>

<div class="detailContainer">

    <h2><%=dto.getTitle()%></h2>

    <div class="infoTop">

        <span>👤 <%=dto.getNickname()%></span>
        &nbsp;&nbsp;

        <span>📍 <%=dto.getRegion()%></span>
        &nbsp;&nbsp;

        <span><%=dto.getReg_date()%></span>

    </div>

    <div class="statusBar">

        조회수 <%=dto.getView_cnt()%>
        &nbsp;&nbsp;

        좋아요 <span id="likeCnt"><%=dto.getLike_cnt()%></span>
        &nbsp;&nbsp;

        즐겨찾기 <span id="bookmarkCnt"><%=dto.getBookmark_cnt()%></span>

    </div>

    <div class="imageArea">

        <%
        if(imgList.size() == 0){
        %>

            <img src="<%=request.getContextPath()%>/images/no-image.png">

        <%
        } else {
            for(ReviewerImageDTO img : imgList){
        %>

            <img src="<%=request.getContextPath()%>/upload/reviewer/<%=img.getFile_name()%>">

        <%
            }
        }
        %>

    </div>

    <div class="contentArea">

        <%=dto.getContent()%>

    </div>

    <div class="btnArea">

        <button type="button"
                onclick="likeToggle(<%=post_id%>)">

            <%
            if(dto.isLiked()){
            %>
                ❤️ 좋아요 취소
            <%
            } else {
            %>
                🤍 좋아요
            <%
            }
            %>

        </button>

        <button type="button"
                onclick="bookmarkToggle(<%=post_id%>)">

            <%
            if(dto.isBookmarked()){
            %>
                ⭐ 즐겨찾기 취소
            <%
            } else {
            %>
                ☆ 즐겨찾기
            <%
            }
            %>

        </button>

        <%
        if(loginUser != null &&
           loginUser.getMember_id() == dto.getMember_id()){
        %>

        <a href="reviewerPostUpdate.jsp?post_id=<%=post_id%>">
            수정
        </a>

        <%
        }
        %>

        <a href="reviewerPostList.jsp">
            목록
        </a>

    </div>

</div>

<script>

/* =========================
   좋아요 AJAX
========================= */
function likeToggle(post_id){

    $.ajax({
        url : "reviewerLikeToggle.jsp",
        type : "post",
        data : { post_id : post_id },
        success : function(){
            location.reload();
        },
        error : function(){
            alert("좋아요 처리 실패");
        }
    });

}

/* =========================
   북마크 AJAX
========================= */
function bookmarkToggle(post_id){

    $.ajax({
        url : "reviewerBookmarkToggle.jsp",
        type : "post",
        data : { post_id : post_id },
        success : function(){
            location.reload();
        },
        error : function(){
            alert("북마크 처리 실패");
        }
    });

}

</script>

</body>
</html>