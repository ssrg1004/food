<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>

<%@ page import="com.oreilly.servlet.MultipartRequest" %>
<%@ page import="com.oreilly.servlet.multipart.DefaultFileRenamePolicy" %>

<%@ page import="web.miniProject.dto.MemberDTO" %>
<%@ page import="web.miniProject.dto.ReviewerPostDTO" %>
<%@ page import="web.miniProject.dao.ReviewerPostDAO" %>

<%
request.setCharacterEncoding("UTF-8");

MemberDTO loginUser = (MemberDTO)session.getAttribute("loginUser");

/* 권한 체크 */
if(loginUser == null || !"Y".equals(loginUser.getReviewer_yn())){
%>
<script>
alert("평가단만 작성 가능합니다.");
location.href="reviewerPostList.jsp";
</script>
<%
    return;
}

/* 업로드 설정 헷갈리지 않게 경로를 upload경로를 revierwer로 하나 더 만들어주세요 */
String path = application.getRealPath("webapp/upload/reviewer");
int size = 10 * 1024 * 1024;

//폴더가 없으면 자동으로 생성해 주는 로직
java.io.File uploadDir = new java.io.File(path);
if (!uploadDir.exists()) {
    uploadDir.mkdirs(); // upload 폴더와 reviewer 폴더를 한 번에 생성
}


MultipartRequest multi =
    new MultipartRequest(request, path, size, "UTF-8",
        new DefaultFileRenamePolicy());

/* 폼 데이터 */
String title = multi.getParameter("title");
String region = multi.getParameter("region");
String content = multi.getParameter("content");

/* DAO */
ReviewerPostDAO dao = ReviewerPostDAO.getInstance();

/* =========================
   1. draft 글 insert
========================= */
ReviewerPostDTO dto =
    new ReviewerPostDTO();

dto.setMember_id(loginUser.getMember_id());
dto.setTitle(title);
dto.setRegion(region);
dto.setContent(content);

int draft_id = dao.insertDraft(dto);

/* =========================
   2. 이미지 insert
========================= */
for(int i=1; i<=3; i++){

    String file =
        multi.getFilesystemName("image"+i);

    if(file != null){

        dao.insertDraftImage(
            draft_id,
            file,
            (i==1 ? "Y" : "N"),
            i
        );
    }
}
%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<link rel="stylesheet" href="<%=request.getContextPath()%>/css/reviewer.css">
</head>
<body>

<script>
alert("작성 완료 (관리자 승인 대기)");
location.href="reviewerPostList.jsp";
</script>

</body>
</html>