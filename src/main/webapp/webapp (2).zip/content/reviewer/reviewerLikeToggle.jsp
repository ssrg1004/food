<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>

<%@ page import="web.miniProject.dto.MemberDTO" %>
<%@ page import="web.miniProject.dao.ReviewerPostDAO" %>

<%
MemberDTO loginUser = (MemberDTO)session.getAttribute("loginUser");
/* =========================
로그인 체크
========================= */
if(loginUser == null){
 response.sendRedirect(request.getContextPath() + "/login.jsp");
 return;
}

/* =========================
파라미터 체크
========================= */
String post_idParam = request.getParameter("post_id");

if(post_idParam == null || post_idParam.trim().equals("")){
    response.sendError(400, "invalid post_id");
    return;
}

int post_id = Integer.parseInt(post_idParam);

ReviewerPostDAO dao = ReviewerPostDAO.getInstance();

/* =========================
   좋아요 토글
   (있으면 삭제 / 없으면 추가)
========================= */
try {

    boolean isLiked = dao.isLiked(post_id, loginUser.getMember_id());

    if(isLiked){
        dao.deleteLike(post_id, loginUser.getMember_id());
    } else {
        dao.insertLike(post_id, loginUser.getMember_id());
    }

} catch(Exception e){
    e.printStackTrace();
    response.sendError(500, "like toggle error");
    return;
}

%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>likeToggle</title>
<link rel="stylesheet" href="<%=request.getContextPath()%>/css/reviewer.css">
</head>
<body>

<script>
    // 부모창 새로고침 (상세페이지에서 AJAX 없이 사용할 때)
    if(window.opener){
        window.opener.location.reload();
        window.close();
    } else {
        location.href = "<%=request.getContextPath()%>/reviewerPostList.jsp";
    }
</script>

</body>
</html>