<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>

<%@ page import="java.util.*" %>
<%@ page import="web.miniProject.dto.MemberDTO" %>
<%@ page import="web.miniProject.dto.ReviewerPostDTO" %>
<%@ page import="web.miniProject.dao.ReviewerPostDAO" %>

<%
MemberDTO sdtoReview = (MemberDTO)session.getAttribute("loginUser");

/* =========================
   파라미터 처리
========================= */
String sort = request.getParameter("sort");
if(sort == null) sort = "latest";

int pageLineSize = 3;

String pageNum = request.getParameter("pageNum");
if(pageNum == null) pageNum = "1";

String pageLineSizeParam =
    request.getParameter("pageLineSize");

if(pageLineSizeParam != null){
    pageLineSize = Integer.parseInt(pageLineSizeParam);
}

int currentPage = Integer.parseInt(pageNum);

int startRow = (currentPage-1) * (pageLineSize*4) + 1;
int endRow = currentPage * (pageLineSize*4);

/* =========================
   DAO
========================= */
ReviewerPostDAO dao = ReviewerPostDAO.getInstance();

ArrayList<ReviewerPostDTO> list = dao.getList(startRow, endRow, sort, sdtoReview);

int count = dao.getCount();
%>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">

<title>맛집평가단 게시판</title>

<link rel="stylesheet"
href="<%=request.getContextPath()%>/css/main.css">

<link rel="stylesheet"
href="<%=request.getContextPath()%>/css/reviewer.css">

</head>

<body>

<jsp:include page="../header.jsp"/>

<div class="restaurantContainer">

    <div class="searchArea">

        <input type="text"
               placeholder="제목, 지역 검색">

        <button>🔍</button>

    </div>

    <div class="sortArea">

        <a href="?sort=latest"
           class="sortBtn <%=sort.equals("latest") ? "active" : ""%>">
            최신순
        </a>

        <a href="?sort=like"
           class="sortBtn <%=sort.equals("like") ? "active" : ""%>">
            좋아요순
        </a>

        <a href="?sort=view"
           class="sortBtn <%=sort.equals("view") ? "active" : ""%>">
            조회순
        </a>

        <a href="?sort=bookmark"
           class="sortBtn <%=sort.equals("bookmark") ? "active" : ""%>">
            즐겨찾기순
        </a>

    </div>

    <%
    if(sdtoReview != null &&
       "Y".equalsIgnoreCase(sdtoReview.getReviewer_yn())){
    %>

    <div class="addRestaurantBtn">

        <a href="reviewerPostWrite.jsp">
            평가글 작성
        </a>

    </div>

    <% } %>

    <div class="restaurantArea">

        <%
        for(ReviewerPostDTO dto : list){
        %>

        <a href="reviewerPostDetail.jsp?post_id=<%=dto.getPost_id()%>"
           class="restaurantCard">

            <div class="cardImage">

                <img src="<%=request.getContextPath()%>/upload/reviewer/<%=dto.getThumbnail() != null ? dto.getThumbnail() : "default.png"%>">

            </div>

            <div class="cardContent">

                <div class="titleRow">

                    <div class="storeName">
                        <%=dto.getTitle()%>
                    </div>

                    <div class="iconArea">

                        <button type="button"
                                class="likeBtn"
                                onclick="event.preventDefault();
                                         event.stopPropagation();
                                         likeToggle(<%=dto.getPost_id()%>)">

                            <%
                            if(dto.isLiked()){
                            %>
                                <img src="<%=request.getContextPath()%>/images/heart-fill.png">
                            <%
                            }else{
                            %>
                                <img src="<%=request.getContextPath()%>/images/heart-empty.png">
                            <%
                            }
                            %>

                        </button>

                        <button type="button"
                                class="bookmarkBtn"
                                onclick="event.preventDefault();
                                         event.stopPropagation();
                                         bookmarkToggle(<%=dto.getPost_id()%>)">

                            <%
                            if(dto.isBookmarked()){
                            %>
                                <img src="<%=request.getContextPath()%>/images/bookmark-fill.png">
                            <%
                            }else{
                            %>
                                <img src="<%=request.getContextPath()%>/images/bookmark-empty.png">
                            <%
                            }
                            %>

                        </button>

                    </div>

                </div>

                <div class="writerRow">
                    👤 <%=dto.getNickname()%>
                </div>

                <div class="addressRow">
                    📍 <%=dto.getRegion()%>
                </div>

                <div class="infoRow">

                    조회수 <%=dto.getView_cnt()%>
                    &nbsp;&nbsp;

                    좋아요 <%=dto.getLike_cnt()%>
                    &nbsp;&nbsp;

                    즐겨찾기 <%=dto.getBookmark_cnt()%>

                </div>

                <div class="dateRow">
                    <%=dto.getReg_date()%>
                </div>

            </div>

        </a>

        <%
        }
        %>

    </div>

    <div class="paging" style="text-align:center">

    <%
    if(count > 0){

        int pageCount =
            count/(pageLineSize*4)
            + (count%(pageLineSize*4)==0 ? 0 : 1);

        int pageBlock = 10;

        int startPage =
            ((currentPage-1)/pageBlock)*pageBlock + 1;

        int endPage =
            startPage + pageBlock - 1;

        if(endPage > pageCount){
            endPage = pageCount;
        }

        if(startPage > pageBlock){
    %>

        <a href="reviewerPostList.jsp?pageNum=<%=startPage-pageBlock%>&sort=<%=sort%>">
            이전
        </a>

    <%
        }

        for(int i=startPage;i<=endPage;i++){
    %>

        <a href="reviewerPostList.jsp?pageNum=<%=i%>&sort=<%=sort%>" 
           class="<%= (i == currentPage) ? "active" : "" %>">
            <%=i%>
        </a>

    <%
        }

        if(endPage < pageCount){
    %>

        <a href="reviewerPostList.jsp?pageNum=<%=startPage+pageBlock%>&sort=<%=sort%>">
            다음
        </a>

    <%
        }
    }
    %>

    </div>

</div>

<script>

function likeToggle(post_id){

    $.ajax({
        url : "reviewerLikeToggle.jsp",
        type : "post",
        data : { post_id : post_id },
        success : function(){
            location.reload();
        }
    });
}

function bookmarkToggle(post_id){

    $.ajax({
        url : "reviewerBookmarkToggle.jsp",
        type : "post",
        data : { post_id : post_id },
        success : function(){
            location.reload();
        }
    });
}

</script>

</body>
</html>