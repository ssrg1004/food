<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>

<%@ page import="web.miniProject.dto.MemberDTO" %>
<%@ page import="web.miniProject.dao.ReviewerPostDAO" %>

<%
MemberDTO loginUser = (MemberDTO)session.getAttribute("loginUser");

if(loginUser == null || !"Y".equals(loginUser.getReviewer_yn())){
%>

<script>
alert("평가단만 작성 가능합니다.");
location.href="reviewerPostList.jsp";
</script>

<%
    return;
}
%>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>평가단 글 작성</title>

<link rel="stylesheet"
href="<%=request.getContextPath()%>/css/main.css">

<link rel="stylesheet"
href="<%=request.getContextPath()%>/css/reviewer.css">

</head>

<body>

<jsp:include page="../header.jsp"/>

<div class="formContainer">

<form action="reviewerPostWritePro.jsp"
      method="post"
      enctype="multipart/form-data">

    <h2>평가단 글 작성</h2>

    <input type="text"
           name="title"
           placeholder="제목을 입력하세요"
           required>

    <input type="text"
           name="region"
           placeholder="지역을 입력하세요 (예: 서울 강남구)">

    <textarea name="content"
              placeholder="맛 평가 내용을 상세히 입력해주세요"
              required></textarea>

    <input type="file"
           name="image1">

    <input type="file"
           name="image2">

    <input type="file"
           name="image3">

    <button type="submit">등록</button>

</form>

</div>

</body>
</html>