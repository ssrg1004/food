<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>

<%@ page import="web.miniProject.dto.*" %>
<%@ page import="web.miniProject.dao.*" %>

<%
MemberDTO loginUser = (MemberDTO)session.getAttribute("loginUser");

String post_idStr = request.getParameter("post_id");

if(post_idStr == null){
    response.sendRedirect("reviewerPostList.jsp");
    return;
}

int post_id = Integer.parseInt(post_idStr);

ReviewerPostDAO dao = ReviewerPostDAO.getInstance();

ReviewerPostDTO dto = dao.getPost(post_id);

/* =========================
   글 없음 처리
========================= */
if(dto == null){
%>
<script>
alert("존재하지 않는 글입니다.");
location.href="reviewerPostList.jsp";
</script>
<%
    return;
}

/* =========================
   권한 체크 (핵심 수정)
========================= */
if(loginUser == null || loginUser.getMember_id() != dto.getMember_id()){
%>

<script>
alert("본인 글만 수정 가능합니다.");
location.href="reviewerPostList.jsp";
</script>

<%
    return;
}
%>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>평가단 글 수정</title>

<link rel="stylesheet"
href="<%=request.getContextPath()%>/css/main.css">

<link rel="stylesheet"
href="<%=request.getContextPath()%>/css/reviewer.css">

</head>

<body>

<jsp:include page="../header.jsp"/>

<div class="formContainer">

<form action="reviewerPostUpdatePro.jsp"
      method="post">

    <input type="hidden"
           name="post_id"
           value="<%=dto.getPost_id()%>">

    <h2>글 수정</h2>

    <input type="text"
           name="title"
           value="<%=dto.getTitle()%>"
           placeholder="제목을 입력하세요">

    <input type="text"
           name="region"
           value="<%=dto.getRegion()%>"
           placeholder="지역을 입력하세요 (예: 서울 강남구)">

    <textarea name="content" placeholder="내용을 입력하세요"><%=dto.getContent()%></textarea>

    <button type="submit">수정</button>

</form>

</div>

</body>
</html>