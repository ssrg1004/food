<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>

<%@ page import="web.miniProject.dto.MemberDTO" %>
<%@ page import="web.miniProject.dao.ReviewerPostDAO" %>

<%
request.setCharacterEncoding("UTF-8");

MemberDTO loginUser = (MemberDTO)session.getAttribute("loginUser");

/* =========================
로그인 체크
========================= */
if(loginUser == null){
 response.sendRedirect(request.getContextPath() + "/login.jsp");
 return;
}

int member_id = loginUser.getMember_id();

/* =========================
파라미터 체크
========================= */
String postIdParam = request.getParameter("post_id");

if(postIdParam == null || postIdParam.trim().equals("")){
 response.sendError(400, "invalid post_id");
 return;
}

int post_id = Integer.parseInt(postIdParam);


ReviewerPostDAO dao = ReviewerPostDAO.getInstance();

/* =========================
북마크 토글 처리
========================= */
try {

 boolean isBookmarked = dao.isBookmarked(post_id, member_id);

 if(isBookmarked){
     dao.deleteBookmark(post_id, member_id);
 } else {
     dao.insertBookmark(post_id, member_id);
 }

} catch(Exception e){
 e.printStackTrace();
 response.sendError(500, "bookmark toggle error");
 return;
}

%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>bookmarkToggle</title>
<link rel="stylesheet" href="<%=request.getContextPath()%>/css/reviewer.css">
</head>
<body>

<script>
    // 부모창 새로고침 (일반 JSP 방식)
    if(window.opener){
        window.opener.location.reload();
        window.close();
    } else {
        location.href = "<%=request.getContextPath()%>/reviewerPostList.jsp";
    }
</script>

</body>
</html>