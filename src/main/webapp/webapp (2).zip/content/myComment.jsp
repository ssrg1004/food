<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
    
<link rel="stylesheet" href="<%=request.getContextPath()%>/css/myComment.css">

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>맛침반</title>
</head>
<body>

<div class="mypageContent">

    <h2 class="commentTitle">
        내 댓글 관리
    </h2>

    <table class="commentTable">

        <thead>
            <tr>
                <th>번호</th>
                <th>리뷰명</th>
                <th>내용</th>
                <th>작성일</th>
                <th>관리</th>
            </tr>
        </thead>

        <tbody>

            <tr>

                <td>15</td>

                <td>
                    <a href="#">
                        성수동 돈까스 맛집
                    </a>
                </td>

                <td>
                    <a href="#">
                        진짜 맛있네요
                    </a>
                </td>

                <td>
                    2026-06-16
                </td>

                <td>

                    <button class="commentEditBtn">
                        수정
                    </button>

                    <button class="commentDeleteBtn">
                        삭제
                    </button>

                </td>

            </tr>

        </tbody>

    </table>

</div>

</body>
</html>