package web.miniProject.dao;

import java.sql.*;
import java.util.ArrayList;

import web.miniProject.dto.MemberDTO;
import web.miniProject.dto.ReviewerPostDTO;
import web.miniProject.dto.ReviewerImageDTO;
import web.miniProject.util.matDBUtil;

public class ReviewerPostDAO {

    private static ReviewerPostDAO instance = new ReviewerPostDAO();

    public static ReviewerPostDAO getInstance() {
        return instance;
    }

    private ReviewerPostDAO() {}

    /* ======================================================
       1. 게시글 수(승인된 게시글 개수)
    ====================================================== */
    public int getCount(){
        int count = 0;

        try(Connection conn = matDBUtil.getConn();
            PreparedStatement pstmt =
                conn.prepareStatement("SELECT COUNT(*) FROM reviewer_post");
            ResultSet rs = pstmt.executeQuery()) {

            if(rs.next()){
                count = rs.getInt(1);
            }

        }catch(Exception e){
            e.printStackTrace();
        }
        return count;
    }

    /* ======================================================
       2. 리스트(게시글 목록) - ROW_NUMBER() 기반 2중 구조로 개선
    ====================================================== */
    public ArrayList<ReviewerPostDTO> getList(int startRow, int endRow, String sort, MemberDTO loginUser){

        ArrayList<ReviewerPostDTO> list = new ArrayList<>();

        try(Connection conn = matDBUtil.getConn()) {

            String orderBy = "p.post_id DESC";
            if("like".equals(sort)) orderBy = "p.like_cnt DESC, p.post_id DESC";
            else if("view".equals(sort)) orderBy = "p.view_cnt DESC, p.post_id DESC";
            else if("bookmark".equals(sort)) orderBy = "p.bookmark_cnt DESC, p.post_id DESC";

            int member_id = (loginUser != null) ? loginUser.getMember_id() : -1;

            String sql =
                "SELECT * FROM ( " +
                "   SELECT p.post_id, p.member_id, p.title, p.region, " +
                "          p.view_cnt, p.like_cnt, p.bookmark_cnt, p.reg_date, " +
                "          m.nickname, " +
                "          (SELECT file_name FROM reviewer_image ri " +
                "           WHERE ri.post_id = p.post_id AND is_thumbnail='Y' AND ROWNUM=1) thumbnail, " +
                "          (SELECT COUNT(*) FROM reviewer_post_like l " +
                "           WHERE l.post_id=p.post_id AND l.member_id=?) liked, " +
                "          (SELECT COUNT(*) FROM reviewer_bookmark b " +
                "           WHERE b.post_id=p.post_id AND b.member_id=?) bookmarked, " +
                "          ROW_NUMBER() OVER(ORDER BY " + orderBy + ") rn " +
                "   FROM reviewer_post p " +
                "   JOIN member m ON p.member_id = m.member_id " +
                ") WHERE rn BETWEEN ? AND ?";

            PreparedStatement pstmt = conn.prepareStatement(sql);

            pstmt.setInt(1, member_id);
            pstmt.setInt(2, member_id);
            pstmt.setInt(3, startRow);
            pstmt.setInt(4, endRow);

            ResultSet rs = pstmt.executeQuery();

            while(rs.next()){
                ReviewerPostDTO dto = new ReviewerPostDTO();

                dto.setPost_id(rs.getInt("post_id"));
                dto.setMember_id(rs.getInt("member_id"));
                dto.setTitle(rs.getString("title"));
                dto.setRegion(rs.getString("region"));
                dto.setView_cnt(rs.getInt("view_cnt"));
                dto.setLike_cnt(rs.getInt("like_cnt"));
                dto.setBookmark_cnt(rs.getInt("bookmark_cnt"));
                dto.setReg_date(rs.getDate("reg_date"));

                dto.setNickname(rs.getString("nickname"));
                dto.setThumbnail(rs.getString("thumbnail"));

                dto.setLiked(rs.getInt("liked") > 0);
                dto.setBookmarked(rs.getInt("bookmarked") > 0);

                list.add(dto);
            }

        }catch(Exception e){
            e.printStackTrace();
        }
        return list;
    }

    /* ======================================================
       3. 게시글 상세 조회
    ====================================================== */
    public ReviewerPostDTO getPost(int post_id){

        ReviewerPostDTO dto = null;

        try(Connection conn = matDBUtil.getConn();
            PreparedStatement pstmt = conn.prepareStatement(
                "SELECT p.*, m.nickname " +
                "FROM reviewer_post p JOIN member m ON p.member_id=m.member_id " +
                "WHERE p.post_id=?"
            )) {

            pstmt.setInt(1, post_id);
            ResultSet rs = pstmt.executeQuery();

            if(rs.next()){
                dto = new ReviewerPostDTO();

                dto.setPost_id(rs.getInt("post_id"));
                dto.setMember_id(rs.getInt("member_id"));
                dto.setTitle(rs.getString("title"));
                dto.setContent(rs.getString("content"));
                dto.setRegion(rs.getString("region"));
                dto.setView_cnt(rs.getInt("view_cnt"));
                dto.setLike_cnt(rs.getInt("like_cnt"));
                dto.setBookmark_cnt(rs.getInt("bookmark_cnt"));
                dto.setReg_date(rs.getDate("reg_date"));
                dto.setNickname(rs.getString("nickname"));
            }

        }catch(Exception e){
            e.printStackTrace();
        }
        return dto;
    }


    /* ======================================================
       4. 이미지 목록 조회
    ====================================================== */
    public ArrayList<ReviewerImageDTO> getImages(int post_id){

        ArrayList<ReviewerImageDTO> list = new ArrayList<>();

        try(Connection conn = matDBUtil.getConn();
            PreparedStatement pstmt =
                conn.prepareStatement("SELECT * FROM reviewer_image WHERE post_id=? ORDER BY image_order")) {

            pstmt.setInt(1, post_id);
            ResultSet rs = pstmt.executeQuery();

            while(rs.next()){
                ReviewerImageDTO dto = new ReviewerImageDTO();

                dto.setImage_id(rs.getInt("image_id"));
                dto.setPost_id(rs.getInt("post_id"));
                dto.setFile_name(rs.getString("file_name"));
                dto.setIs_thumbnail(rs.getString("is_thumbnail"));
                dto.setImage_order(rs.getInt("image_order"));

                list.add(dto);
            }

        }catch(Exception e){
            e.printStackTrace();
        }
        return list;
    }

    /* ======================================================
       5. 조회수 증가
    ====================================================== */
    public void increaseViewCnt(int post_id){
        Connection conn = null;
        PreparedStatement pstmt = null;

        try{
            conn = matDBUtil.getConn();
            String sql =
                 "UPDATE reviewer_post " +
                 "SET view_cnt = view_cnt + 1 " +
                 "WHERE post_id=? ";

            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, post_id);

            int result = pstmt.executeUpdate();
            if(result == 0){
                System.out.println("[WARNING] 조회수 증가 실패 - post_id: " + post_id);
            }
        }catch(Exception e){
             e.printStackTrace();
        }finally{
            close(null, pstmt, conn);
        }
    }

    /* ======================================================
       6. DRAFT 게시글 등록/수정 요청 초안 (draft) 저장
    ====================================================== */
    public int insertDraft(ReviewerPostDTO dto){
        int draft_id = 0;
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try{
            conn = matDBUtil.getConn();
            String sql =
                "INSERT INTO reviewer_post_draft " +
                "(draft_id, post_id, member_id, request_type, status, title, content, region, request_date) " +
                "VALUES (reviewer_draft_seq.NEXTVAL, NULL, ?, 'insert', 'wait', ?, ?, ?, SYSDATE)";

            // 표준 JDBC 방식 규격 유지 (CURRVAL보다 동시성에 안전함)
            pstmt = conn.prepareStatement(sql, new String[]{"draft_id"});
            pstmt.setInt(1, dto.getMember_id());
            pstmt.setString(2, dto.getTitle());
            pstmt.setString(3, dto.getContent());
            pstmt.setString(4, dto.getRegion());

            pstmt.executeUpdate();
            rs = pstmt.getGeneratedKeys();

            if(rs.next()){
                draft_id = rs.getInt(1);
            }
        }catch(Exception e){
            e.printStackTrace();
        }finally{
            close(rs, pstmt, conn);
        }
        return draft_id;
    }

    public void updateDraft(ReviewerPostDTO dto){
        Connection conn = null;
        PreparedStatement pstmt = null;

        try{
            conn = matDBUtil.getConn();
            String sql =
                "INSERT INTO reviewer_post_draft " +
                "(draft_id, post_id, member_id, request_type, status, title, content, region, request_date) " +
                "VALUES (reviewer_draft_seq.NEXTVAL, ?, ?, 'update', 'wait', ?, ?, ?, SYSDATE)";

            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, dto.getPost_id());
            pstmt.setInt(2, dto.getMember_id());
            pstmt.setString(3, dto.getTitle());
            pstmt.setString(4, dto.getContent());
            pstmt.setString(5, dto.getRegion());

            pstmt.executeUpdate();
        }catch(Exception e){
            e.printStackTrace();
        }finally{
            close(null, pstmt, conn);
        }
    }

    public void insertDraftImage(int draft_id, String fileName, String is_thumbnail, int order){
        Connection conn = null;
        PreparedStatement pstmt = null;

        try{
            conn = matDBUtil.getConn();
            String sql =
                "INSERT INTO reviewer_image_draft " +
                "(image_id, draft_id, file_name, is_thumbnail, image_order) " +
                "VALUES (reviewer_image_draft_seq.NEXTVAL, ?, ?, ?, ?)";

            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, draft_id);
            pstmt.setString(2, fileName);
            pstmt.setString(3, is_thumbnail);
            pstmt.setInt(4, order);

            pstmt.executeUpdate();
        }catch(Exception e){
            e.printStackTrace();
        }finally{
            close(null, pstmt, conn);
        }
    }


    /* ======================================================
    7. 게시글 DELETE 삭제 요청 및 검증
	====================================================== */

	 // [추가] 이미 삭제 요청 대기 중인지 확인하는 메서드
	 public boolean isAlreadyDrafted(int post_id) {
	     boolean result = false;
	     String sql = "SELECT 1 FROM reviewer_post_draft WHERE post_id=? AND status='wait' AND ROWNUM=1";
	
	     try (Connection conn = matDBUtil.getConn();
	          PreparedStatement pstmt = conn.prepareStatement(sql)) {
	         
	         pstmt.setInt(1, post_id);
	         try (ResultSet rs = pstmt.executeQuery()) {
	             if (rs.next()) {
	                 result = true; // 이미 대기 중인 요청이 있음
	             }
	         }
	     } catch (Exception e) {
	         e.printStackTrace();
	     }
	     return result;
	 }
	
	 // [수정] 예외를 throws하여 JSP에서 성공 여부를 판단할 수 있도록 변경
	 public void deleteDraft(int post_id, int member_id) throws Exception {
	     String sql = "INSERT INTO reviewer_post_draft " +
	                  "(draft_id, post_id, member_id, request_type, status, request_date) " +
	                  "VALUES (reviewer_draft_seq.NEXTVAL, ?, ?, 'delete', 'wait', SYSDATE)";
	
	     // Try-with-resources 구문으로 자동으로 close() 보장
	     try (Connection conn = matDBUtil.getConn();
	          PreparedStatement pstmt = conn.prepareStatement(sql)) {
	         
	         pstmt.setInt(1, post_id);
	         pstmt.setInt(2, member_id);
	
	         pstmt.executeUpdate();
	     } catch (Exception e) {
	         e.printStackTrace();
	         throw e; // JSP(컨트롤러)단으로 예외를 던짐
	     }
	 }
	 
	 // [수정] Short-Circuit 최적화 유지 + Try-with-resources 적용
	 public boolean isWriter(int post_id, int member_id) {
	     boolean result = false;
	     String sql = "SELECT 1 FROM reviewer_post WHERE post_id=? AND member_id=? AND ROWNUM=1";
	
	     try (Connection conn = matDBUtil.getConn();
	          PreparedStatement pstmt = conn.prepareStatement(sql)) {
	         
	         pstmt.setInt(1, post_id);
	         pstmt.setInt(2, member_id);
	
	         try (ResultSet rs = pstmt.executeQuery()) {
	             if (rs.next()) {
	                 result = true; 
	             }
	         }
	     } catch (Exception e) {
	         e.printStackTrace();
	     }
	     return result;
	 }
    
    /* ======================================================
       8. LIKE 좋아요 확인 추가 삭제
    ====================================================== */
    public boolean isLiked(int post_id, int member_id){
        boolean result = false;
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try{
            conn = matDBUtil.getConn();
            String sql = "SELECT COUNT(*) FROM reviewer_post_like WHERE post_id=? AND member_id=?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, post_id);
            pstmt.setInt(2, member_id);

            rs = pstmt.executeQuery();
            if(rs.next()) result = rs.getInt(1) > 0;
        }catch(Exception e){
            e.printStackTrace();
        }finally{
            close(rs, pstmt, conn);
        }
        return result;
    }

    public void insertLike(int post_id, int member_id){
        Connection conn = null;
        PreparedStatement pstmt1 = null;
        PreparedStatement pstmt2 = null;

        try{
            conn = matDBUtil.getConn();
            conn.setAutoCommit(false);

            String sql1 = "INSERT INTO reviewer_post_like(post_id, member_id) VALUES(?,?)";
            pstmt1 = conn.prepareStatement(sql1);
            pstmt1.setInt(1, post_id);
            pstmt1.setInt(2, member_id);
            pstmt1.executeUpdate();

            // 버그 수정: 초기 값이 0일 때도 정상 누적되도록 단순 연산으로 변경
            String sql2 = "UPDATE reviewer_post SET like_cnt = like_cnt + 1 WHERE post_id=?";
            pstmt2 = conn.prepareStatement(sql2);
            pstmt2.setInt(1, post_id);
            pstmt2.executeUpdate();

            conn.commit();
        }catch(Exception e){
            try{ if(conn != null) conn.rollback(); }catch(Exception ex){}
            e.printStackTrace();
        }finally{
            // 개별 try-catch 구조 분리로 자원 유실 원천 차단
            try { if(pstmt2 != null) pstmt2.close(); } catch(Exception e){}
            try { if(pstmt1 != null) pstmt1.close(); } catch(Exception e){}
            try { if(conn != null) conn.close(); } catch(Exception e){}
        }
    }

    public void deleteLike(int post_id, int member_id){
        Connection conn = null;
        PreparedStatement pstmt1 = null;
        PreparedStatement pstmt2 = null;

        try{
            conn = matDBUtil.getConn();
            conn.setAutoCommit(false);

            String sql1 = "DELETE FROM reviewer_post_like WHERE post_id=? AND member_id=?";
            pstmt1 = conn.prepareStatement(sql1);
            pstmt1.setInt(1, post_id);
            pstmt1.setInt(2, member_id);
            pstmt1.executeUpdate();

            String sql2 = "UPDATE reviewer_post SET like_cnt = CASE WHEN like_cnt > 0 THEN like_cnt - 1 ELSE 0 END WHERE post_id=?";
            pstmt2 = conn.prepareStatement(sql2);
            pstmt2.setInt(1, post_id);
            pstmt2.executeUpdate();

            conn.commit();
        }catch(Exception e){
            try{ if(conn != null) conn.rollback(); }catch(Exception ex){}
            e.printStackTrace();
        }finally{
            try { if(pstmt2 != null) pstmt2.close(); } catch(Exception e){}
            try { if(pstmt1 != null) pstmt1.close(); } catch(Exception e){}
            try { if(conn != null) conn.close(); } catch(Exception e){}
        }
    }

    /* ======================================================
       9. BOOKMARK 확인 추가 삭제
    ====================================================== */
    public boolean isBookmarked(int post_id, int member_id){
        boolean result = false;
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try{
            conn = matDBUtil.getConn();
            String sql = "SELECT COUNT(*) FROM reviewer_bookmark WHERE post_id=? AND member_id=?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, post_id);
            pstmt.setInt(2, member_id);

            rs = pstmt.executeQuery();
            if(rs.next()) result = rs.getInt(1) > 0;
        }catch(Exception e){
            e.printStackTrace();
        }finally{
            close(rs, pstmt, conn);
        }
        return result;
    }

    public void insertBookmark(int post_id, int member_id){
        Connection conn = null;
        PreparedStatement pstmt1 = null;
        PreparedStatement pstmt2 = null;

        try{
            conn = matDBUtil.getConn();
            conn.setAutoCommit(false);

            String sql1 = "INSERT INTO reviewer_bookmark(post_id, member_id) VALUES(?,?)";
            pstmt1 = conn.prepareStatement(sql1);
            pstmt1.setInt(1, post_id);
            pstmt1.setInt(2, member_id);
            pstmt1.executeUpdate();

            String sql2 = "UPDATE reviewer_post SET bookmark_cnt = bookmark_cnt + 1 WHERE post_id=?";
            pstmt2 = conn.prepareStatement(sql2);
            pstmt2.setInt(1, post_id);
            pstmt2.executeUpdate();

            conn.commit();
        }catch(Exception e){
            try{ if(conn != null) conn.rollback(); }catch(Exception ex){}
            e.printStackTrace();
        }finally{
            try { if(pstmt2 != null) pstmt2.close(); } catch(Exception e){}
            try { if(pstmt1 != null) pstmt1.close(); } catch(Exception e){}
            try { if(conn != null) conn.close(); } catch(Exception e){}
        }
    }

    public void deleteBookmark(int post_id, int member_id){
        Connection conn = null;
        PreparedStatement pstmt1 = null;
        PreparedStatement pstmt2 = null;

        try{
            conn = matDBUtil.getConn();
            conn.setAutoCommit(false);

            String sql1 = "DELETE FROM reviewer_bookmark WHERE post_id=? AND member_id=?";
            pstmt1 = conn.prepareStatement(sql1);
            pstmt1.setInt(1, post_id);
            pstmt1.setInt(2, member_id);
            pstmt1.executeUpdate();

            String sql2 = "UPDATE reviewer_post SET bookmark_cnt = CASE WHEN bookmark_cnt > 0 THEN bookmark_cnt - 1 ELSE 0 END WHERE post_id=?";
            pstmt2 = conn.prepareStatement(sql2);
            pstmt2.setInt(1, post_id);
            pstmt2.executeUpdate();

            conn.commit();
        }catch(Exception e){
            try{ if(conn != null) conn.rollback(); }catch(Exception ex){}
            e.printStackTrace();
        }finally{
            try { if(pstmt2 != null) pstmt2.close(); } catch(Exception e){}
            try { if(pstmt1 != null) pstmt1.close(); } catch(Exception e){}
            try { if(conn != null) conn.close(); } catch(Exception e){}
        }
    }

    /* ======================================================
       10. CLOSE 공통 메소드
    ====================================================== */
    private void close(ResultSet rs, PreparedStatement pstmt, Connection conn){
        try { if(rs != null) rs.close(); } catch(Exception e){}
        try { if(pstmt != null) pstmt.close(); } catch(Exception e){}
        try { if(conn != null) conn.close(); } catch(Exception e){}
    }
}