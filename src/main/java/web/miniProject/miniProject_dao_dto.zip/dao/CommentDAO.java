package web.miniProject.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import web.miniProject.dto.CommentDTO;
import web.miniProject.util.matDBUtil;

public class CommentDAO {

	private Connection conn = null;
	private PreparedStatement pstmt = null;
	private ResultSet rs = null;
	private String sql = null;
	
	// 내가 쓴 댓글 전체 개수 조회(삭제댓글 제외)
	public int myComment_count(int member_id) {
		int result = 0;
		Connection conn = null;
		try {
			conn = matDBUtil.getConn();
			sql = "select count(*) " + 
					" from restaurant_comment " + 
					" where member_id=? and delete_yn='N'";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, member_id);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				result = rs.getInt(1);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			matDBUtil.close(conn, pstmt, rs);
		}
		return result;
	}
	
	// 내가 쓴 댓글 목록 불러오기(삭제댓글 제외)
	public List<CommentDTO> getMyCommentList(int member_id, int startRow, int endRow) {

	    List<CommentDTO> list = new ArrayList<CommentDTO>();

	    try {
	        conn = matDBUtil.getConn();
	        sql = "select * from ( " +
        	      "    select " +
        	      "        row_number() over (order by comment_id desc) rn, " +
        	      "        c.*, " +
        	      "        m.nickname, " +
        	      "        p.title " +
        	      "    from restaurant_comment c " +
        	      "    inner join member m " +
        	      "        on c.member_id = m.member_id " +
        	      "    inner join restaurant_post p " +
        	      "        on c.post_id = p.post_id " +
        	      "    where c.member_id=? and c.delete_yn='N' " +
        	      ") " +
        	      "where rn between ? and ?";

	        pstmt = conn.prepareStatement(sql);

	        pstmt.setInt(1, member_id);
	        pstmt.setInt(2, startRow);
	        pstmt.setInt(3, endRow);

	        rs = pstmt.executeQuery();

	        while(rs.next()) {
	            CommentDTO dto = new CommentDTO();

	            dto.setComment_id(rs.getInt("comment_id"));
	            dto.setPost_id(rs.getInt("post_id"));
	            dto.setMember_id(rs.getInt("member_id"));
	            dto.setParent_id((Integer)rs.getObject("parent_id"));
	            dto.setContent(rs.getString("content"));
	            dto.setStar_score(rs.getInt("star_score"));
	            dto.setDelete_yn(rs.getString("delete_yn"));
	            dto.setStatus(rs.getString("status"));
	            dto.setReg_date(rs.getString("reg_date"));
	            dto.setNickname(rs.getString("nickname"));
	            dto.setPost_title(rs.getString("title"));
	            list.add(dto);
	        }

	    } catch(Exception e) {
	        e.printStackTrace();
	    } finally {
	        matDBUtil.close(conn,pstmt,rs);
	    }
	    return list;
	}
	
	// 부모 댓글 개수 조회
	public int comment_count(int post_id) {
		int result = 0;
		Connection conn = null;
		try {
			conn = matDBUtil.getConn();
			sql = "select count(*) " + 
					" from restaurant_comment " + 
					" where post_id=? and parent_id is null and delete_yn='N'";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, post_id);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				result = rs.getInt(1);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			matDBUtil.close(conn, pstmt, rs);
		}
		return result;
	}
	
	// 부모 댓글 목록 불러오기
	public List<CommentDTO> getCommentList(int post_id, int startRow, int endRow) {

	    List<CommentDTO> list = new ArrayList<CommentDTO>();

	    try {
	        conn = matDBUtil.getConn();
	        sql = "select * from ( " +
        	      "    select " +
        	      "        row_number() over (order by comment_id desc) rn, " +
        	      "        c.*, " +
        	      "        m.nickname " +
        	      "    from restaurant_comment c " +
        	      "    inner join member m " +
        	      "        on c.member_id = m.member_id " +
        	      "    where c.post_id=? and c.parent_id is null and c.delete_yn='N' " +
        	      ") " +
        	      "where rn between ? and ?";

	        pstmt = conn.prepareStatement(sql);

	        pstmt.setInt(1, post_id);
	        pstmt.setInt(2, startRow);
	        pstmt.setInt(3, endRow);

	        rs = pstmt.executeQuery();

	        while(rs.next()) {
	            CommentDTO dto = new CommentDTO();

	            dto.setComment_id(rs.getInt("comment_id"));
	            dto.setPost_id(rs.getInt("post_id"));
	            dto.setMember_id(rs.getInt("member_id"));
	            dto.setParent_id((Integer)rs.getObject("parent_id"));
	            dto.setContent(rs.getString("content"));
	            dto.setStar_score(rs.getInt("star_score"));
	            dto.setDelete_yn(rs.getString("delete_yn"));
	            dto.setStatus(rs.getString("status"));
	            dto.setReg_date(rs.getString("reg_date"));
	            dto.setNickname(rs.getString("nickname"));
	            list.add(dto);
	        }

	    } catch(Exception e) {
	        e.printStackTrace();
	    } finally {
	        matDBUtil.close(conn,pstmt,rs);
	    }
	    return list;
	}
	
	// 댓댓글 불러오기
	public List<CommentDTO> getReplyList(int parent_id) {

	    List<CommentDTO> list =new ArrayList<CommentDTO>();

	    try {
	        conn = matDBUtil.getConn();
	        sql = "select c.*, m.nickname" +
	        	      " from restaurant_comment c" +
	        	      " inner join member m" +
	        	      "     on c.member_id = m.member_id " +
	        	      " where c.parent_id = ? " +
	        	      " and c.delete_yn = 'N' " +
	        	      " order by c.comment_id desc";
	        
	        pstmt = conn.prepareStatement(sql);
	        pstmt.setInt(1,parent_id);
	        rs = pstmt.executeQuery();

	        while(rs.next()) {
	            CommentDTO dto = new CommentDTO();
	            dto.setComment_id(rs.getInt("comment_id"));
	            dto.setPost_id(rs.getInt("post_id"));
	            dto.setMember_id(rs.getInt("member_id"));
	            dto.setParent_id(rs.getInt("parent_id"));
	            dto.setContent( rs.getString("content"));
	            dto.setDelete_yn(rs.getString("delete_yn"));
	            dto.setStatus(rs.getString("status"));
	            dto.setReg_date(rs.getString("reg_date"));
	            dto.setNickname(rs.getString("nickname"));
	            list.add(dto);
	        }

	    } catch(Exception e) {
	        e.printStackTrace();
	    } finally {
	        matDBUtil.close(conn,pstmt,rs);
	    }
	    return list;
	}
	
	// 댓글 등록
	public int insertComment(CommentDTO dto) {
	    int result = 0;

	    try {
	        conn = matDBUtil.getConn();
	        sql = "insert into restaurant_comment " +
	        	      " (comment_id, post_id, member_id, parent_id, content, star_score) " +
	        	      " values (comment_seq.nextval, ?, ?, ?, ?, ?)";

	        pstmt = conn.prepareStatement(sql);
	        pstmt.setInt(1,dto.getPost_id());
	        pstmt.setInt(2,dto.getMember_id());
	        if(dto.getParent_id() == null){
	            pstmt.setNull(3, java.sql.Types.NUMERIC);
	        }else{
	            pstmt.setInt(3, dto.getParent_id());
	        }
	        pstmt.setString(4,dto.getContent());
	        pstmt.setInt(5,dto.getStar_score());

	        result = pstmt.executeUpdate();

	    } catch(Exception e) {
	        e.printStackTrace();
	    } finally {
	        matDBUtil.close(conn, pstmt, rs);
	    }
	    return result;
	}
	// 답글 등록
	public int insertReply(CommentDTO dto) {
	    int result = 0;

	    try {
	        conn = matDBUtil.getConn();
	        sql = "insert into restaurant_comment " +
	        	      " (comment_id, post_id, member_id, parent_id, content) " +
	        	      " values (comment_seq.nextval, ?, ?, ?, ?)";

	        pstmt = conn.prepareStatement(sql);
	        pstmt.setInt(1,dto.getPost_id());
	        pstmt.setInt(2,dto.getMember_id());
	        pstmt.setObject(3,dto.getParent_id());
	        pstmt.setString(4,dto.getContent());

	        result =  pstmt.executeUpdate();

	    } catch(Exception e) {
	        e.printStackTrace();
	    } finally {
	        matDBUtil.close(conn, pstmt, rs);
	    }

	    return result;
	}
	
	// 댓글 수정
	public int updateComment(CommentDTO dto) {
	    int result = 0;

	    try {
	        conn = matDBUtil.getConn();
	        sql =
	            "update restaurant_comment " +
	            " set content=? " +
	            " where comment_id=?" +
	            " and member_id=?";
	        pstmt = conn.prepareStatement(sql);
	        pstmt.setString(1,dto.getContent());
	        pstmt.setInt(2,dto.getComment_id());
	        pstmt.setInt(3, dto.getMember_id());

	        result = pstmt.executeUpdate();

	    } catch(Exception e) {
	        e.printStackTrace();
	    } finally {
	        matDBUtil.close(conn, pstmt, rs);
	    }
	    return result;
	}
	
	// 댓글 삭제
	public int deleteComment(int comment_id, int member_id) {
	    int result = 0;

	    try {
	        conn = matDBUtil.getConn();
	        sql =
	            "update restaurant_comment " +
	            " set delete_yn='Y' " +
	            " where comment_id=? " +
	        	" and member_id=?";
	        pstmt = conn.prepareStatement(sql);
	        pstmt.setInt(1,comment_id);
	        pstmt.setInt(2, member_id);
	        result = pstmt.executeUpdate();
	    } catch(Exception e) {
	        e.printStackTrace();
	    } finally {
	        matDBUtil.close(conn, pstmt, rs);
	    }
	    return result;
	}
	
	// 댓글 신고여부
	public boolean isReported(int comment_id, int reporter_id){

	    boolean result = false;

	    try{
	        conn = matDBUtil.getConn();

	        sql =
	            "SELECT COUNT(*) " +
	            "FROM COMMENT_REPORT " +
	            "WHERE COMMENT_ID=? AND REPORTER_ID=?";

	        pstmt = conn.prepareStatement(sql);
	        pstmt.setInt(1, comment_id);
	        pstmt.setInt(2, reporter_id);

	        rs = pstmt.executeQuery();

	        if(rs.next()){
	            result = rs.getInt(1) > 0;
	        }
	    }catch(Exception e){
	        e.printStackTrace();
	    }

	    return result;
	}
	
	// 댓글 신고
	public int reportComment(int comment_id, int reporter_id, String reason) {
		int result = 0;
		
		try {
			conn = matDBUtil.getConn();
			sql = "insert into comment_report " +  
					" (report_id, comment_id, reporter_id, reason) " +
					" values(report_seq.nextval, ?, ?, ?) ";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, comment_id);
		    pstmt.setInt(2, reporter_id);
		    pstmt.setString(3, reason);
			
		    result = pstmt.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
	        matDBUtil.close(conn, pstmt, rs);
	    }
		
		return result;
	}
}
