package web.miniProject.dao;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MyPostSearchDAO {
	
	private Connection conn = null;
	private PreparedStatement pstmt = null;
	private ResultSet rs = null;
	private String sql = null;
	/*
	// 내 좋아요 글 목록
	sql = "select " +
		      "    p.post_id, " +
		      "    i.file_name as thumbnail, " +
		      "    r.name as restaurant_name, " +
		      "    m.nickname, " +
		      "    p.like_cnt, " +
		      "    p.bookmark_cnt, " +
		      "    nvl(c.comment_cnt, 0) as comment_cnt " +
		      "from restaurant_post_like l " +	// 좋아요 테이블
		      
		      "inner join restaurant_post p " +
		      "    on l.post_id = p.post_id " +	// ㅣ
		      
		      "inner join member m " +
		      "    on p.member_id = m.member_id " +
		      
		      "inner join restaurant r " +
		      "    on p.restaurant_id = r.restaurant_id " +
		      
		      "left join restaurant_image i " +
		      "    on p.post_id = i.post_id " +
		      "    and i.is_thumbnail = 'Y' " +
		      
		      "left join ( " +
		      "    select " +
		      "        post_id, " +
		      "        count(*) as comment_cnt " +
		      "    from restaurant_comment " +
		      "    where delete_yn = 'N' " +
		      "    group by post_id " +
		      ") c " +
		      "    on p.post_id = c.post_id " +
		      
		      "where l.member_id = ? " +	// ㅣ
		      
		      "order by p.reg_date desc";
	*/
	/*
	// 내 즐겨찾기 글 목록
	sql = "select " +
		      "    p.post_id, " +
		      "    i.file_name as thumbnail, " +
		      "    r.name as restaurant_name, " +
		      "    m.nickname, " +
		      "    p.like_cnt, " +
		      "    p.bookmark_cnt, " +
		      "    nvl(c.comment_cnt, 0) as comment_cnt " +
		      "from restaurant_bookmark b " +	// 좋아요 테이블
		      
		      "inner join restaurant_post p " +
		      "    on b.post_id = p.post_id " +	// b
		      
		      "inner join member m " +
		      "    on p.member_id = m.member_id " +
		      
		      "inner join restaurant r " +
		      "    on p.restaurant_id = r.restaurant_id " +
		      
		      "left join restaurant_image i " +
		      "    on p.post_id = i.post_id " +
		      "    and i.is_thumbnail = 'Y' " +
		      
		      "left join ( " +
		      "    select " +
		      "        post_id, " +
		      "        count(*) as comment_cnt " +
		      "    from restaurant_comment " +
		      "    where delete_yn = 'N' " +
		      "    group by post_id " +
		      ") c " +
		      "    on p.post_id = c.post_id " +
		      
		      "where b.member_id = ? " +	// b
		      
		      "order by p.reg_date desc";
	*/
	/*
	// 내가 쓴 댓글목록
	
	// 총 내 댓글 수 조회
	sql = "select count(*) " +
	      "from restaurant_comment " +
	      "where member_id = ? " +
	      "and delete_yn = 'n'";
	
	// 댓글 조회
	public list<CommentDTO> getMyCommentList(int member_id, int startRow, int endRow){
	
	}
	
	
	sql = "select * " +
	      "from ( " +
	      "    select " +
	      "        row_number() over ( " +
	      "            order by c.reg_date desc, c.comment_id desc " +
	      "        ) rn, " +      
	      "        c.comment_id, " +
	      "        c.post_id, " +
	      "        r.name as restaurant_name, " +
	      "        p.title as post_title, " +
	      "        c.content, " +
	      "        c.reg_date " +
	      
	      "    from restaurant_comment c " +
	      
	      "    inner join restaurant_post p " +
	      "        on c.post_id = p.post_id " +
	      
	      "    inner join restaurant r " +
	      "        on p.restaurant_id = r.restaurant_id " +
	      
	      "    where c.member_id = ? " +
	      "    and c.delete_yn = 'N' " +
	      ") " +
	      "where rn between ? and ?";
	*/
	/*
	// 내가 쓴 글 목록
	sql = "select " +
		      "    p.post_id, " +
		      "    i.file_name as thumbnail, " +
		      "    r.name as restaurant_name, " +
		      "    m.nickname, " +
		      "    p.like_cnt, " +
		      "    p.bookmark_cnt, " +
		      "    nvl(c.comment_cnt, 0) as comment_cnt " +
		      "from restaurant_post p " +

		      "inner join member m " +
		      "    on p.member_id = m.member_id " +
		      
		      "inner join restaurant r " +
		      "    on p.restaurant_id = r.restaurant_id " +
		      
		      "left join restaurant_image i " +
		      "    on p.post_id = i.post_id " +
		      "    and i.is_thumbnail = 'Y' " +
		      
		      "left join ( " +
		      "    select " +
		      "        post_id, " +
		      "        count(*) as comment_cnt " +
		      "    from restaurant_comment " +
		      "    where delete_yn = 'N' " +
		      "    group by post_id " +
		      ") c " +
		      "    on p.post_id = c.post_id " +
		      
		      "where p.member_id = ? " +
		      
		      "order by p.reg_date desc";
	*/
}
