package web.miniProject.dto;

public class RestaurantDTO {

	
	boolean liked = true;		// 좋아요 확인용 (테스트로 true 넣음. 작성시는 true값 제거하기)
	boolean bookmarked = true;	// 북마크 확인용 (테스트로 true 넣음. 작성시는 true값 제거하기)
}
