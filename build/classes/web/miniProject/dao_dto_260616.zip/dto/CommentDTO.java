package web.miniProject.dto;

public class CommentDTO {
	private int comment_id;
	private int post_id;
	private int member_id;
	private int parent_id;
	private String content;
	private int star_score;
	private char delete_yn;
	private String reg_date;
	private String nickname;
	private String post_title;

	// getter
	public int getComment_id() { return this.comment_id; }
	public int getPost_id() { return this.post_id; }
	public int getMember_id() { return this.member_id; }
	public int getParent_id() { return this.parent_id; }
	public String getContent() { return this.content; }
	public int getStar_score() { return this.star_score; }
	public char getDelete_yn() { return this.delete_yn; }
	public String getReg_date() { return this.reg_date; }
	public String getNickname() { return this.nickname; }
	public String getPost_title() { return post_title; }
	
	// setter
	public void setComment_id(int comment_id) { this.comment_id = comment_id; }
	public void setPost_id(int post_id) { this.post_id = post_id; }
	public void setMember_id(int member_id) { this.member_id = member_id; }
	public void setParent_id(int parent_id) { this.parent_id = parent_id; }
	public void setContent(String content) { this.content = content; }
	public void setStar_score(int star_score) { this.star_score = star_score; }
	public void setDelete_yn(char delete_yn) { this.delete_yn = delete_yn; }
	public void setReg_date(String reg_date) { this.reg_date = reg_date; }
	public void setNickname(String nickname) { this.nickname = nickname; }
	public void setPost_title(String post_title) { this.post_title = post_title; }
}
